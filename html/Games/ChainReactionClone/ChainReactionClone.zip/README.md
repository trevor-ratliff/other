# Chain Reaction #

## About ##

Chain Reaction was a game I used to play on our Texas Instruments Pegasus Personal Computer in the 80's.  It had no hard drive and used 2 5 1/4 floppy disks.

I want to make a clone of the game as close to the original play as possible.  I spent many happy hours playing this game.

---

## Ideas ##

There are some things I still need to finish.  I need to get the bugs worked out of the edge cases and I would like to write a simple AI for a one player game.

---
